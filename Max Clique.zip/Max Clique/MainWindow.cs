﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaxClique
{
    public partial class MainWindow : Form
    {
        Graph actualGraph;
        string fileName;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void readFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Plik z grafem (.grph)|*.grph";
            dialog.RestoreDirectory = false;
            dialog.InitialDirectory = "~/";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                fileName = dialog.FileName;
                actualGraph = Graph.ReadFromFile(fileName);
                if (actualGraph == null)
                    MessageBox.Show("Wczytanie z pliku zakończyło się niepowodzeniem");
                else
                    fileName = dialog.FileName;
            }
        }

        private void solve_Click(object sender, EventArgs e)
        {
            if (actualGraph == null)
            {
                MessageBox.Show("Wczytanie z pliku zakończyło się niepowodzeniem");
                return;
            }
            fileName = fileName.Replace(".grph", ".clq");

            List<int> clique = Graph.FindMaxClique(actualGraph);
            if (Graph.WriteToFile(clique, fileName))
                MessageBox.Show("Obliczenie i zapis do pliku zakończył się sukcesem");
            else
                MessageBox.Show("Obliczenie lub zapis zakończyło się porażką");
        }
    }
}
