﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaxClique
{
    /// <summary>
    /// Reprezentuje graf zapisany za pomocą macierzy incydencji
    /// </summary>
    public class Graph
    {
        /// <summary>
        /// Liczba wierzchołków grafu
        /// </summary>
        public int N { set; get; }

        /// <summary>
        /// Macierz incydencji grafu
        /// </summary>
        public bool[,] incidencyMatrix;

        /// <summary>
        /// Tworzy graf o danej liczbie wierzchołków bez krawędzi.
        /// </summary>
        /// <param name="n">Liczba wierzchołków grafu</param>
        public Graph(int n)
        {
            N = n;
            incidencyMatrix = new bool[n, n];
        }

        /// <summary>
        /// Tworzy dopełnienie grafu wejściowego.
        /// </summary>
        /// <param name="source">Graf, którego dopełnienie jest tworzone</param>
        /// <returns>Graf, będący dopełnieniem grafu wejściowego</returns>
        public Graph EnclosureGraph()
        {
            Graph enclosure = new Graph(N);
            for (int i = 0; i < enclosure.N; i++)
                for (int j = 0; j < enclosure.N; j++)
                    enclosure.incidencyMatrix[i, j] = (i != j && !incidencyMatrix[i, j]);
            return enclosure;
        }

        /// <summary>
        /// Znajduje maksymalną klikę w grafie za pomocą algorytmu aproksymacyjnego.
        /// </summary>
        /// <param name="graph">Graf, w którym poszukujemy kliki</param>
        /// <returns>Lista indeksów wierzchołków, które znajdują się w znalezionej klice</returns>
        public static List<int> FindMaxClique(Graph graph)
        {
            var enclosure = graph.EnclosureGraph();
            bool[] setC = new bool[graph.N];
            bool[,] edges = (bool[,])enclosure.incidencyMatrix.Clone();

            for (int lastEdgeFrom = 0; lastEdgeFrom < graph.N; lastEdgeFrom++)
                for (int lastEdgeTo = 0; lastEdgeTo < graph.N; lastEdgeTo++)
                {
                    if (edges[lastEdgeFrom, lastEdgeTo])
                    {
                        setC[lastEdgeFrom] = true;
                        setC[lastEdgeTo] = true;
                        for (int i = 0; i < graph.N; i++)
                        {
                            edges[lastEdgeFrom, i] = false;
                            edges[lastEdgeTo, i] = false;
                            edges[i, lastEdgeFrom] = false;
                            edges[i, lastEdgeTo] = false;
                        }
                        break;
                    }
                }
            List<int> maxClique = new List<int>();
            for (int i = 0; i < setC.Length; i++)
                if (!setC[i])
                    maxClique.Add(i);
            return maxClique;
        }

        /// <summary>
        /// Wypisuje liczbę wierzchołków i indeksy wierzchołków należących do maksymalnej kliki do pliku.
        /// </summary>
        /// <param name="maxClique">Lista indeksów wierzchołków należących do maksymalnej kliki</param>
        /// <param name="fileName">Nazwa pliku wyjściowego</param>
        /// <returns>Informacja, czy zapis do pliku się udał</returns>
        public static bool WriteToFile(List<int> maxClique,string fileName)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(fileName,false))
                {
                    writer.WriteLine(maxClique.Count);
                    if(maxClique.Count>0) writer.Write(maxClique[0]);
                    for (int i = 1; i < maxClique.Count; i++)
                        writer.Write("," + maxClique[i]);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Wczytuje graf z pliku wejściowego.
        /// </summary>
        /// <param name="fileName">Nazwa pliku wejściowego</param>
        /// <returns>Graf wczytany z pliku</returns>
        public static Graph ReadFromFile(string fileName)
        {
            try
            {
                using (StreamReader reader = new StreamReader(fileName))
                {
                    Graph graph = new Graph(int.Parse(reader.ReadLine()));
                    while (!reader.EndOfStream)
                    {
                        string[] verticies = reader.ReadLine().Split(':', ',');
                        for (int i = 1; i < verticies.Length; i++)
                            graph.incidencyMatrix[int.Parse(verticies[0]), int.Parse(verticies[i])] = true;
                    }
                    return graph;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
