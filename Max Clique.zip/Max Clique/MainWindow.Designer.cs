﻿namespace MaxClique
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.readFile = new System.Windows.Forms.Button();
            this.solve = new System.Windows.Forms.Button();
            this.text = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // readFile
            // 
            this.readFile.Location = new System.Drawing.Point(24, 68);
            this.readFile.Name = "readFile";
            this.readFile.Size = new System.Drawing.Size(75, 23);
            this.readFile.TabIndex = 0;
            this.readFile.Text = "Wczytaj plik";
            this.readFile.UseVisualStyleBackColor = true;
            this.readFile.Click += new System.EventHandler(this.readFile_Click);
            // 
            // solve
            // 
            this.solve.Location = new System.Drawing.Point(165, 68);
            this.solve.Name = "solve";
            this.solve.Size = new System.Drawing.Size(75, 23);
            this.solve.TabIndex = 1;
            this.solve.Text = "Rozwiąż";
            this.solve.UseVisualStyleBackColor = true;
            this.solve.Click += new System.EventHandler(this.solve_Click);
            // 
            // text
            // 
            this.text.Location = new System.Drawing.Point(12, 9);
            this.text.Name = "text";
            this.text.Size = new System.Drawing.Size(260, 56);
            this.text.TabIndex = 2;
            this.text.Text = "Program rozwiązuje problem znalezienia maksymalnej kliki za pomocą algorytmu apro" +
    "ksymacyjnego";
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 107);
            this.Controls.Add(this.text);
            this.Controls.Add(this.solve);
            this.Controls.Add(this.readFile);
            this.MinimumSize = new System.Drawing.Size(300, 145);
            this.Name = "MainWindow";
            this.Text = "Max klika";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button readFile;
        private System.Windows.Forms.Button solve;
        private System.Windows.Forms.Label text;
    }
}

